import{bD as i}from"./index-DS3lypRw.js";function c(e){const[s,r]=i.useState(()=>typeof window<"u"&&window.innerWidth>=e);return i.useEffect(()=>{const t=window.matchMedia(`(min-width: ${e}px)`),n=a=>r(a.matches);return t.addEventListener("change",n),()=>t.removeEventListener("change",n)},[e]),s}export{c as u};
//# sourceMappingURL=useMinWidth-l7jLTYzd.js.map
