import{c3 as s,c5 as a,c7 as n,c6 as o}from"./index-DxE8-dNl.js";function t({storeSlug:r}){const e=s({queryKey:o.seller.categories(r),queryFn:()=>a(n.seller.categories),enabled:r.length>0});return{data:e.data,isLoading:e.isLoading,error:e.error}}export{t as u};
//# sourceMappingURL=useCategoriesQuery-DBfGodt5.js.map
