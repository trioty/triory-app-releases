import{c3 as n,c5 as i,c7 as a,c6 as u}from"./index-DxE8-dNl.js";function t({storeSlug:r,enabled:s=!0}){const e=n({queryKey:u.seller.shippingRules(r),queryFn:()=>i(a.seller.storeShippingRules,{cache:"no-store"}),enabled:r.length>0&&s});return{data:e.data,isLoading:e.isLoading,error:e.error}}export{t as u};
//# sourceMappingURL=useShippingRulesQuery-D_ksfNpp.js.map
