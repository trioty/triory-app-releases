const A=/[ؐ-ًؚ-ٰٟۖ-ۭ࣓-ࣣ࣡-ࣿ]/g,r=/ـ/g,c=/[آأإٱ]/g,a=/ى/g,n=/ة/g,o=/\s+/g;function t(e){return e.normalize("NFC").replace(A,"").replace(r,"").replace(c,"ا").replace(a,"ي").replace(n,"ه").toLowerCase().replace(o," ").trim()}export{t as n};
//# sourceMappingURL=area-name-normalizer-Chl5Ned5.js.map
