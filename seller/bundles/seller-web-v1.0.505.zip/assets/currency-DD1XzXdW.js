const e="ar-EG",a="ج.م.";function m(r,t,n="EGP"){const o=t==="ar"?e:t;return new Intl.NumberFormat(o,{style:"currency",currency:n,maximumFractionDigits:0}).format(r).replace(a,"ج.م")}export{m as f};
//# sourceMappingURL=currency-DD1XzXdW.js.map
