function i(t,n){const o=n.split("-")[0]==="ar"?"، ":", ";return t.filter(r=>r.trim().length>0).join(o)}export{i as j};
//# sourceMappingURL=list-BQrnJ1AE.js.map
