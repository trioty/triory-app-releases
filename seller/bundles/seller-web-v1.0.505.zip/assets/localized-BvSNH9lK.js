function m(e,c,d){const r=n=>{if(n==null)return;const t=n.trim();return t.length>0?t:void 0},i=r(c),o=r(d);return e==="en"?o??i??"":i??o??""}export{m as p};
//# sourceMappingURL=localized-BvSNH9lK.js.map
