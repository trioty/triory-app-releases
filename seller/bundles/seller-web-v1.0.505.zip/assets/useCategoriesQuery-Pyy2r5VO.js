import{c3 as s,c5 as a,c7 as n,c6 as o}from"./index-CdqDacFr.js";function t({storeSlug:r}){const e=s({queryKey:o.seller.categories(r),queryFn:()=>a(n.seller.categories),enabled:r.length>0});return{data:e.data,isLoading:e.isLoading,error:e.error}}export{t as u};
//# sourceMappingURL=useCategoriesQuery-Pyy2r5VO.js.map
