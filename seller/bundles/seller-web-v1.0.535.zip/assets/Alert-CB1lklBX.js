import{ds as c,bD as u}from"./index-BgXFFJcg.js";function f({message:r,helperText:t}){const o=c(),n=u.useRef(null);return u.useEffect(()=>{const s=`error:${r}:${t??""}`;n.current!==s&&(n.current=s,o.error(r,t))},[t,r,o]),null}export{f as A};
//# sourceMappingURL=Alert-CB1lklBX.js.map
