import{dR as c,bD as s}from"./index-BE5aTc2P.js";function f({message:r,helperText:t}){const o=c(),n=s.useRef(null);return s.useEffect(()=>{const u=`error:${r}:${t??""}`;n.current!==u&&(n.current=u,o.error(r,t))},[t,r,o]),null}export{f as A};
//# sourceMappingURL=Alert-N4wACQkh.js.map
