import{bD as a}from"./index-BE5aTc2P.js";function u(t){const[e,r]=a.useState(t);return t&&!e&&r(!0),e||t}export{u};
//# sourceMappingURL=useLatch-C34ODHLQ.js.map
