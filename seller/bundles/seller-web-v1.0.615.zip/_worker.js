// Pages advanced mode: only /api routes invoke this worker (_routes.json).
// Keep the production API origin fixed; request headers cannot select a backend.
const SELLER_ORIGIN = "https://seller.trioty.com";
const API_HOST = "trioty-api-806882096455.europe-west3.run.app";

function unavailable(code, status) {
  return new Response(JSON.stringify({ code, message: code }), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== "/api" && !url.pathname.startsWith("/api/")) {
      return env.ASSETS.fetch(request);
    }
    // Preview deployments must never proxy production credentials or writes.
    if (url.origin !== SELLER_ORIGIN) {
      return unavailable("SELLER_API_HOST_UNAVAILABLE", 404);
    }

    const headers = new Headers(request.headers);
    for (const name of [...headers.keys()]) {
      if (name === "host" || name === "forwarded" || name === "x-real-ip" || name.startsWith("x-forwarded-")) {
        headers.delete(name);
      }
    }
    headers.set("X-Forwarded-Host", url.hostname);
    headers.set("X-Forwarded-Proto", "https");
    url.hostname = API_HOST;
    url.port = "";

    const upstreamRequest = new Request(new Request(url, request), {
      headers,
      // OAuth redirects and their host-only cookies belong to the browser.
      redirect: "manual",
      cache: "no-store",
    });
    try {
      const upstream = await fetch(upstreamRequest);
      // Preserve streaming bodies, redirects, and every separate Set-Cookie.
      const response = new Response(upstream.body, upstream);
      response.headers.set("Cache-Control", "no-store");
      return response;
    } catch {
      return unavailable("API_UPSTREAM_UNAVAILABLE", 502);
    }
  },
};
