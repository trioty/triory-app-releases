import{bD as a}from"./index-b2_qDcbS.js";function u(t){const[e,r]=a.useState(t);return t&&!e&&r(!0),e||t}export{u};
//# sourceMappingURL=useLatch-bt-DbGxV.js.map
