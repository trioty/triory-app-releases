import{c8 as n,ca as a,cb as i,c9 as u}from"./index-b2_qDcbS.js";function t({storeSlug:r,enabled:s=!0}){const e=n({queryKey:u.seller.shippingRules(r),queryFn:()=>a(i.seller.storeShippingRules,{cache:"no-store"}),enabled:r.length>0&&s});return{data:e.data,isLoading:e.isLoading,error:e.error}}export{t as u};
//# sourceMappingURL=useShippingRulesQuery-D3QVCQz4.js.map
