import{bD as a}from"./index-Nhymh2Nb.js";function u(t){const[e,r]=a.useState(t);return t&&!e&&r(!0),e||t}export{u};
//# sourceMappingURL=useLatch-CzHgPl6X.js.map
