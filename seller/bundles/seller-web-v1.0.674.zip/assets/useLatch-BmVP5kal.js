import{bD as a}from"./index-DPbnPoJB.js";function u(t){const[e,r]=a.useState(t);return t&&!e&&r(!0),e||t}export{u};
//# sourceMappingURL=useLatch-BmVP5kal.js.map
